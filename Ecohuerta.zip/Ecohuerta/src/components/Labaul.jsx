export default function Labaul() {
  return (
    <section id="labaul" className="py-24 max-w-5xl mx-auto px-6">
      <h2 className="text-3xl font-semibold text-green-700 mb-4">Labaul</h2>
      <p className="text-gray-700 leading-relaxed">
        Aquí puedes colocar la información del laboratorio o huerto.
      </p>
    </section>
  );
}
