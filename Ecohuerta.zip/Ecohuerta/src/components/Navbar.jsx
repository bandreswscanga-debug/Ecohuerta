import { useState } from "react";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="bg-green-700 text-white fixed w-full top-0 shadow">
      <nav className="max-w-5xl mx-auto flex items-center justify-between p-4">

        <h1 className="text-xl font-semibold">EcoHuerta</h1>

        <button
          className="md:hidden text-2xl"
          onClick={() => setOpen(!open)}
        >
        </button>

        <ul className={`md:flex gap-6 font-medium ${open ? "block" : "hidden"}`}>
          <li><a href="#inicio" className="hover:underline">Inicio</a></li>
          <li><a href="#labaul" className="hover:underline">Labaul</a></li>
          <li><a href="#contacto" className="hover:underline">Contáctanos</a></li>
        </ul>
      </nav>
    </header>
  );
}
