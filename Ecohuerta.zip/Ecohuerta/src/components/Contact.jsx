export default function Contacto() {
  return (
    <section id="contacto" className="py-24 max-w-5xl mx-auto px-6">
      <h2 className="text-3xl font-semibold text-green-700 mb-4">Contáctanos</h2>
      <p className="text-gray-700 mb-4">Déjanos tus datos y nos comunicaremos contigo.</p>

      <form className="grid gap-4 max-w-md">
        <input type="text" placeholder="Nombre" className="border p-2 rounded" />
        <input type="email" placeholder="Correo" className="border p-2 rounded" />
        <textarea placeholder="Mensaje" className="border p-2 rounded"></textarea>

        <button className="bg-green-700 hover:bg-green-800 text-white py-2 rounded">
          Enviar
        </button>
      </form>
    </section>
  );
}
