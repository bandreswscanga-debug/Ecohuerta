export default function Home() {
  return (
    <section id="inicio" className="h-screen flex items-center justify-center text-center px-6">
      <div>
        <h2 className="text-4xl font-bold text-green-700 mb-4">Bienvenido a EcoHuerta</h2>
        <p className="text-lg text-gray-700">Cuidando la tierra, cuidamos la vida.</p>
      </div>
    </section>
  );
}
