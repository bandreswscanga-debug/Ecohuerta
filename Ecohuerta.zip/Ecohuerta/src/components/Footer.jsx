export default function Footer() {
  return (
    <footer className="bg-blue-600 text-white text-center py-4 mt-10">
      <p>© 2025 Mi Sitio Web — Gracias por visitarnos.</p>
    </footer>
  );
}
