import Navbar from "./components/Navbar";
import Home from "./components/Home";
import Labaul from "./components/Labaul";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <main className="min-h-screen bg-gray-100 flex flex-col items-center gap-16">
      <Navbar />
      
      <section id="inicio" className="w-full max-w-5xl px-6">
        <Home />
      </section>

      <section id="labaul" className="w-full max-w-5xl px-6">
        <Labaul />
      </section>

      <section id="contacto" className="w-full max-w-5xl px-6">
        <Contact />
      </section>

      <Footer />
    </main>
  );
}
